import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vc-child',
  template: ``,
  styleUrls: ['./vc-child.component.css']
})
export class VcChildComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
