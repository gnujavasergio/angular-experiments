import {Component, Input, EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'app-alert',
  template: ``
})
export class ClientCardComponent {
}
